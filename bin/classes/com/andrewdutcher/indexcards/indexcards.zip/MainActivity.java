package com.andrewdutcher.indexcards;


import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends Activity {
	
	private CardDrawer mview;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mview = new CardDrawer(this);
        setContentView(mview);
        /*int x = 3;
        int y = 20;
        int x1 = 0;
        int y1 = 3;
        int x2 = 4;
        int y2 = 1;
        int x3 = -1;
        int y3 = 1;
        int xp = x-x1;
        int yp = y-y1;
        double w = Math.sqrt(Math.pow(x2-x1, 2) + Math.pow(y2-y1, 2));
        double h = Math.sqrt(Math.pow(x3-x1, 2) + Math.pow(y3-y1, 2));
        double cw = (xp*(x2-x1)/w) + (yp*(y2-y1)/h);
        double ch = (xp*(x3-x1)/w) + (yp*(y3-y1)/h);
        boolean first = (0 <= cw) && (cw <= w);
        boolean second = (0 <= ch) && (ch <= h);
        boolean third = first && second;*/
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.menu_settings:
                mview.swap();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
