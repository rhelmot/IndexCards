package com.andrewdutcher.indexcards;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.View;

public class CardDrawer extends View {
	
	public ArrayList<IndexCard> cards;
	
	public void swap() {
		cards.get(0).swap();
	}
	
	public CardDrawer(Context context) {
		super(context);
		cards = new ArrayList<IndexCard>();
		Rect r = new Rect();
		r.left = 200;
		r.top = 100;
		r.right = 700;
		r.bottom = 400;
		cards.add(new IndexCard("Hello, world!", r));
		cards.get(0).rotation = 30;
	}
	protected void onDraw(Canvas c) {
		for (int i = 0; i < cards.size(); i++) {
			c.save();
			cards.get(i).onDraw(c);
			c.restore();
		}
	}
	public boolean onTouchEvent(MotionEvent e) {
		Integer action = e.getAction() & MotionEvent.ACTION_MASK;
		if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN)
		{
			int index = 0;
			if (action == MotionEvent.ACTION_POINTER_DOWN)
			{
				index = (e.getAction() & MotionEvent.ACTION_POINTER_INDEX_MASK) >> MotionEvent.ACTION_POINTER_INDEX_SHIFT;
			}
			float tx = e.getX(index);
			float ty = e.getY(index);
			for (int i = cards.size() - 1; i >= 0; i--) {	//TODO: adapt to z-indexing proper
				IndexCard tc = cards.get(i);
				Vector am = new Vector(false, tx - tc.cardDim.left, ty - tc.cardDim.top, 0);
				Vector ab = new Vector(false, tc.cardDim.width()*Math.cos(Math.toRadians(tc.rotation)), tc.cardDim.width()*Math.sin(Math.toRadians(tc.rotation)), 0);
				Vector ad = new Vector(false, tc.cardDim.height()*Math.cos(Math.toRadians(tc.rotation-90)), tc.cardDim.height()*Math.sin(Math.toRadians(tc.rotation-90)), 0);
				Double amb = am.dot(ab);
				Double amd = am.dot(ad);
				Double abb = ab.dot(ab);
				Double add = ad.dot(ad);
				if ((amb > 0 && abb > amb) != (amd > 0 && add > amd)) {		//lots of math to check if point is within transformed rectangle
					return tc.addPoint(e, index);
				}
				
			}
		}
		else if (action == MotionEvent.ACTION_MOVE || action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL)
		{
			int size = cards.size();
			for (int i = 0; i < size; i++)
				cards.get(i).processTouches(e);
			invalidate();
			return true;
		}
		else
		{
			//return true;
		}
		return false;
	}
}
